
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface MetricCardProps {
  icon: LucideIcon;
  title: string;
  value: string;
  description: string;
  color: string;
}

const MetricCard = ({ icon: Icon, title, value, description, color }: MetricCardProps) => {
  return (
    <Card className="backdrop-blur-xl bg-white/15 border-white/30 hover:bg-white/20 transition-all duration-300 hover:scale-105 animate-fade-in shadow-xl hover:shadow-2xl group overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full blur-2xl transform translate-x-12 -translate-y-12"></div>
      
      <CardHeader className="pb-4 relative z-10">
        <CardTitle className="flex items-center gap-3 text-white">
          <div className={`p-2 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 group-hover:scale-110 transition-transform duration-300`}>
            <Icon className={`h-6 w-6 ${color}`} />
          </div>
          <span className="text-lg font-semibold">{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="relative z-10">
        <div className="space-y-3">
          <p className="text-4xl font-bold text-white group-hover:scale-105 transition-transform duration-300">
            {value}
          </p>
          <p className="text-white/80 text-base leading-relaxed">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default MetricCard;
