
import { Card, CardContent } from "@/components/ui/card";
import { Thermometer, MapPin, Calendar, Clock } from "lucide-react";

interface WeatherData {
  name: string;
  main: {
    temp: number;
    feels_like: number;
    humidity: number;
  };
  weather: Array<{
    main: string;
    description: string;
    icon: string;
  }>;
  wind: {
    speed: number;
  };
  visibility: number;
  sys: {
    country: string;
  };
  coord?: {
    lat: number;
    lon: number;
  };
}

interface WeatherCardProps {
  weatherData: WeatherData;
  isLoading: boolean;
}

const WeatherCard = ({ weatherData, isLoading }: WeatherCardProps) => {
  const getWeatherEmoji = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'clear':
        return '☀️';
      case 'clouds':
        return '☁️';
      case 'rain':
        return '🌧️';
      case 'snow':
        return '❄️';
      case 'thunderstorm':
        return '⛈️';
      case 'drizzle':
        return '🌦️';
      case 'mist':
      case 'fog':
        return '🌫️';
      default:
        return '🌤️';
    }
  };

  const getCurrentTime = () => {
    return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getCurrentDate = () => {
    return new Date().toLocaleDateString([], { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  if (isLoading) {
    return (
      <Card className="backdrop-blur-xl bg-white/15 border-white/30 shadow-2xl animate-pulse max-w-4xl mx-auto">
        <CardContent className="p-12">
          <div className="h-64 bg-white/10 rounded-2xl"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="backdrop-blur-xl bg-white/15 border-white/30 shadow-2xl hover:bg-white/20 transition-all duration-500 animate-scale-in max-w-4xl mx-auto overflow-hidden group">
      <CardContent className="p-0">
        <div className="relative">
          {/* Decorative background elements */}
          <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-white/5"></div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl transform translate-x-32 -translate-y-32"></div>
          
          <div className="relative p-12">
            {/* Header with location and time */}
            <div className="flex justify-between items-start mb-8">
              <div className="flex items-center gap-3">
                <MapPin className="h-6 w-6 text-white/80" />
                <div>
                  <h2 className="text-3xl font-bold text-white">
                    {weatherData.name}
                  </h2>
                  {/* Removed country display */}
                  {weatherData.coord && (
                    <p className="text-white/70 text-sm">
                      {weatherData.coord.lat.toFixed(2)}°, {weatherData.coord.lon.toFixed(2)}°
                    </p>
                  )}
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 text-white/80 mb-1">
                  <Clock className="h-4 w-4" />
                  <span className="text-lg font-medium">{getCurrentTime()}</span>
                </div>
                <div className="flex items-center gap-2 text-white/60">
                  <Calendar className="h-4 w-4" />
                  <span className="text-sm">{getCurrentDate()}</span>
                </div>
              </div>
            </div>

            {/* Main weather display */}
            <div className="grid md:grid-cols-2 gap-12 items-center">
              {/* Left side - Weather icon and description */}
              <div className="text-center md:text-left">
                <div className="mb-6">
                  <div className="text-9xl mb-4 animate-pulse inline-block transform group-hover:scale-110 transition-transform duration-300">
                    {getWeatherEmoji(weatherData.weather[0].main)}
                  </div>
                  <p className="text-white/90 text-2xl capitalize font-medium">
                    {weatherData.weather[0].description}
                  </p>
                </div>
              </div>

              {/* Right side - Temperature and details */}
              <div className="text-center md:text-right">
                <div className="mb-8">
                  <div className="flex items-center justify-center md:justify-end gap-3 mb-4">
                    <Thermometer className="h-8 w-8 text-white/80" />
                    <span className="text-8xl font-bold text-white leading-none">
                      {Math.round(weatherData.main.temp)}°
                    </span>
                  </div>
                  <p className="text-white/80 text-xl">
                    Feels like {Math.round(weatherData.main.feels_like)}°C
                  </p>
                </div>

                {/* Temperature range indicator */}
                <div className="bg-white/10 rounded-2xl p-6 backdrop-blur-sm border border-white/20">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="text-center">
                      <p className="text-white/60 text-sm mb-1">Current</p>
                      <p className="text-white text-2xl font-bold">
                        {Math.round(weatherData.main.temp)}°C
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-white/60 text-sm mb-1">Condition</p>
                      <p className="text-white text-lg font-semibold capitalize">
                        {weatherData.weather[0].main}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WeatherCard;
