
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, MapPin, Thermometer, Eye, Wind, Droplets, Locate } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import WeatherCard from "./WeatherCard";
import MetricCard from "./MetricCard";
import AnimatedBackground from "./AnimatedBackground";

interface WeatherData {
  name: string;
  main: {
    temp: number;
    feels_like: number;
    humidity: number;
  };
  weather: Array<{
    main: string;
    description: string;
    icon: string;
  }>;
  wind: {
    speed: number;
  };
  visibility: number;
  sys: {
    country: string;
  };
  coord?: {
    lat: number;
    lon: number;
  };
}

// Mock API function - replace with actual OpenWeatherMap API
const fetchWeatherData = async (city: string): Promise<WeatherData> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Mock data - replace with actual API call
  return {
    name: city,
    main: {
      temp: Math.floor(Math.random() * 30) + 10,
      feels_like: Math.floor(Math.random() * 30) + 10,
      humidity: Math.floor(Math.random() * 50) + 30,
    },
    weather: [{
      main: "Clear",
      description: "clear sky",
      icon: "01d"
    }],
    wind: {
      speed: Math.floor(Math.random() * 10) + 2,
    },
    visibility: Math.floor(Math.random() * 5000) + 5000,
    sys: {
      country: "IN"
    },
    coord: {
      lat: 18.5204,
      lon: 73.8567
    }
  };
};

const fetchWeatherByCoords = async (lat: number, lon: number): Promise<WeatherData> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Mock data based on coordinates - replace with actual API call
  const cities = ['Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata'];
  const randomCity = cities[Math.floor(Math.random() * cities.length)];
  
  return {
    name: randomCity,
    main: {
      temp: Math.floor(Math.random() * 30) + 15,
      feels_like: Math.floor(Math.random() * 30) + 15,
      humidity: Math.floor(Math.random() * 50) + 40,
    },
    weather: [{
      main: "Clear",
      description: "clear sky",
      icon: "01d"
    }],
    wind: {
      speed: Math.floor(Math.random() * 8) + 3,
    },
    visibility: Math.floor(Math.random() * 5000) + 6000,
    sys: {
      country: "IN"
    },
    coord: {
      lat,
      lon
    }
  };
};

const WeatherDashboard = () => {
  const [searchCity, setSearchCity] = useState("");
  const [currentCity, setCurrentCity] = useState("Pune");
  const [coordinates, setCoordinates] = useState<{lat: number, lon: number} | null>(null);
  const [isUsingLocation, setIsUsingLocation] = useState(false);

  const { data: weatherData, isLoading, error } = useQuery({
    queryKey: ['weather', currentCity, coordinates],
    queryFn: () => {
      if (coordinates && isUsingLocation) {
        return fetchWeatherByCoords(coordinates.lat, coordinates.lon);
      }
      return fetchWeatherData(currentCity);
    },
    refetchInterval: 300000, // Refetch every 5 minutes
  });

  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Location not supported",
        description: "Geolocation is not supported by this browser.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Getting location",
      description: "Fetching your current location...",
    });

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setCoordinates({ lat: latitude, lon: longitude });
        setIsUsingLocation(true);
        toast({
          title: "Location found",
          description: "Getting weather for your current location",
        });
      },
      (error) => {
        let errorMessage = "Unable to get your location";
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location access denied by user";
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information unavailable";
            break;
          case error.TIMEOUT:
            errorMessage = "Location request timed out";
            break;
        }
        toast({
          title: "Location error",
          description: errorMessage,
          variant: "destructive",
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      }
    );
  };

  const handleSearch = () => {
    if (searchCity.trim()) {
      setCurrentCity(searchCity.trim());
      setSearchCity("");
      setIsUsingLocation(false);
      setCoordinates(null);
      toast({
        title: "Searching weather",
        description: `Getting weather data for ${searchCity}`,
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const getWeatherGradient = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'clear':
        return 'from-blue-400 via-blue-500 to-blue-600';
      case 'clouds':
        return 'from-gray-400 via-gray-500 to-gray-600';
      case 'rain':
        return 'from-blue-600 via-blue-700 to-blue-800';
      case 'snow':
        return 'from-blue-200 via-blue-300 to-blue-400';
      default:
        return 'from-blue-400 via-blue-500 to-blue-600';
    }
  };

  return (
    <div className={`min-h-screen relative overflow-hidden bg-gradient-to-br ${weatherData ? getWeatherGradient(weatherData.weather[0].main) : 'from-blue-400 via-blue-500 to-blue-600'} transition-all duration-1000`}>
      {/* Animated Background */}
      <AnimatedBackground weatherCondition={weatherData?.weather[0].main || 'clear'} />
      
      {/* Overlay for better content visibility */}
      <div className="absolute inset-0 bg-black/10 backdrop-blur-[0.5px]"></div>
      
      {/* Main Content */}
      <div className="relative z-10 p-4">
        <div className="max-w-7xl mx-auto">
          {/* Enhanced Header */}
          <div className="text-center mb-12 animate-fade-in">
            <div className="relative inline-block">
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 drop-shadow-2xl tracking-tight">
                <span className="bg-gradient-to-r from-white via-blue-100 to-white bg-clip-text text-transparent">
                  Weather
                </span>
                <br />
                <span className="bg-gradient-to-r from-blue-100 via-white to-blue-100 bg-clip-text text-transparent">
                  Dashboard
                </span>
              </h1>
              <div className="absolute -inset-4 bg-white/5 blur-xl rounded-full -z-10"></div>
            </div>
            <p className="text-white/90 text-xl md:text-2xl font-light max-w-2xl mx-auto leading-relaxed">
              Experience real-time weather updates with stunning visuals
            </p>
          </div>

          {/* Enhanced Search */}
          <div className="mb-12 max-w-2xl mx-auto">
            <Card className="backdrop-blur-xl bg-white/15 border-white/30 shadow-2xl hover:bg-white/20 transition-all duration-300 animate-fade-in">
              <CardContent className="p-8">
                <div className="flex gap-4">
                  <div className="relative flex-1">
                    <MapPin className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/70 h-5 w-5" />
                    <Input
                      placeholder="Search for any city worldwide..."
                      value={searchCity}
                      onChange={(e) => setSearchCity(e.target.value)}
                      onKeyPress={handleKeyPress}
                      className="pl-12 h-14 bg-white/10 border-white/30 text-white text-lg placeholder-white/60 focus:border-white/50 focus:bg-white/15 transition-all duration-200 rounded-xl"
                    />
                  </div>
                  <Button 
                    onClick={handleSearch}
                    className="h-14 px-8 bg-white/20 hover:bg-white/30 text-white border-white/30 transition-all duration-200 rounded-xl shadow-lg hover:shadow-xl"
                  >
                    <Search className="h-5 w-5" />
                  </Button>
                  <Button 
                    onClick={getCurrentLocation}
                    className="h-14 px-8 bg-emerald-500/30 hover:bg-emerald-500/40 text-white border-white/30 transition-all duration-200 rounded-xl shadow-lg hover:shadow-xl"
                    title="Get current location weather"
                  >
                    <Locate className="h-5 w-5" />
                  </Button>
                </div>
                {isUsingLocation && (
                  <div className="mt-4 text-center">
                    <p className="text-white/80 text-sm">📍 Using your current location</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {error && (
            <Card className="mb-8 backdrop-blur-md bg-red-500/20 border-red-300/30 max-w-2xl mx-auto">
              <CardContent className="p-6">
                <p className="text-white text-center text-lg">Failed to fetch weather data. Please try again.</p>
              </CardContent>
            </Card>
          )}

          {/* Enhanced Main Weather Display */}
          {weatherData && (
            <div className="grid gap-8 md:gap-12">
              {/* Current Weather Card */}
              <div className="animate-scale-in">
                <WeatherCard weatherData={weatherData} isLoading={isLoading} />
              </div>
              
              {/* Enhanced Weather Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
                <div className="animate-fade-in" style={{ animationDelay: '0.1s' }}>
                  <MetricCard
                    icon={Droplets}
                    title="Humidity"
                    value={`${weatherData.main.humidity}%`}
                    description="Relative humidity level"
                    color="text-cyan-300"
                  />
                </div>
                <div className="animate-fade-in" style={{ animationDelay: '0.2s' }}>
                  <MetricCard
                    icon={Wind}
                    title="Wind Speed"
                    value={`${weatherData.wind.speed} m/s`}
                    description="Current wind velocity"
                    color="text-emerald-300"
                  />
                </div>
                <div className="animate-fade-in" style={{ animationDelay: '0.3s' }}>
                  <MetricCard
                    icon={Eye}
                    title="Visibility"
                    value={`${(weatherData.visibility / 1000).toFixed(1)} km`}
                    description="Atmospheric visibility"
                    color="text-purple-300"
                  />
                </div>
              </div>
            </div>
          )}

          {isLoading && (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="relative">
                <div className="animate-spin rounded-full h-16 w-16 border-4 border-white/20 border-t-white"></div>
                <div className="absolute inset-0 rounded-full bg-white/5 blur-xl"></div>
              </div>
              <p className="text-white/80 mt-4 text-lg">Loading weather data...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WeatherDashboard;
