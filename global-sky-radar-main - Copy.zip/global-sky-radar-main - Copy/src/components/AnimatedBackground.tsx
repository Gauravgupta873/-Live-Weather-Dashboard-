
import { useEffect, useState } from "react";

interface AnimatedBackgroundProps {
  weatherCondition: string;
}

const AnimatedBackground = ({ weatherCondition }: AnimatedBackgroundProps) => {
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; size: number; opacity: number; speed: number }>>([]);

  useEffect(() => {
    const generateParticles = () => {
      const newParticles = [];
      const particleCount = weatherCondition.toLowerCase() === 'rain' ? 100 : 50;
      
      for (let i = 0; i < particleCount; i++) {
        newParticles.push({
          id: i,
          x: Math.random() * 100,
          y: Math.random() * 100,
          size: Math.random() * 4 + 1,
          opacity: Math.random() * 0.8 + 0.2,
          speed: Math.random() * 2 + 1,
        });
      }
      setParticles(newParticles);
    };

    generateParticles();
  }, [weatherCondition]);

  const getParticleStyle = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'rain':
        return 'bg-blue-200/40';
      case 'snow':
        return 'bg-white/60 rounded-full';
      case 'clouds':
        return 'bg-gray-200/30 rounded-full';
      default:
        return 'bg-yellow-200/30 rounded-full';
    }
  };

  const getAnimationClass = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'rain':
        return 'animate-rain';
      case 'snow':
        return 'animate-snow';
      default:
        return 'animate-float';
    }
  };

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Floating geometric shapes */}
      <div className="absolute top-10 left-10 w-32 h-32 bg-white/5 rounded-full blur-xl animate-pulse"></div>
      <div className="absolute top-1/4 right-20 w-48 h-48 bg-blue-200/10 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      <div className="absolute bottom-1/4 left-1/4 w-40 h-40 bg-cyan-200/10 rounded-full blur-xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      <div className="absolute bottom-10 right-10 w-56 h-56 bg-white/5 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '0.5s' }}></div>

      {/* Weather-specific particles */}
      {particles.map((particle) => (
        <div
          key={particle.id}
          className={`absolute ${getParticleStyle(weatherCondition)} ${getAnimationClass(weatherCondition)}`}
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: `${particle.size}px`,
            height: weatherCondition.toLowerCase() === 'rain' ? `${particle.size * 4}px` : `${particle.size}px`,
            opacity: particle.opacity,
            animationDuration: `${particle.speed}s`,
            animationDelay: `${Math.random() * 2}s`,
          }}
        />
      ))}

      {/* Gradient overlays for depth */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/10"></div>
      <div className="absolute inset-0 bg-gradient-radial from-white/5 via-transparent to-transparent"></div>
    </div>
  );
};

export default AnimatedBackground;
