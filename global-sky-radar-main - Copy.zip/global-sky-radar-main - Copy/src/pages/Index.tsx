
import WeatherDashboard from "../components/WeatherDashboard";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-blue-500 to-blue-600">
      <WeatherDashboard />
    </div>
  );
};

export default Index;
